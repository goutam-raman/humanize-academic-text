---
name: "humanize-academic-text"
description: "Rewrite an abstract, proposal, essay or other academic text the user wrote so it reads human and scores low on AI detectors (ZeroGPT, GPTZero), using the DIPPER and SICO methods plus live detector checks."
---

# Humanize academic text (detector-aware rewrite)

Built from two papers and from what actually worked against ZeroGPT in November 2026:
- Krishna et al. (NeurIPS 2023), "Paraphrasing evades detectors of AI-generated text" (DIPPER)
- Lu et al. (TMLR 2024), "Large Language Models can be Guided to Evade AI-Generated Text Detection" (SICO)


## Ground rules
- Lock the content first. Every claim, number, citation, sector, method and stakeholder in the user's text must survive. Never add facts, examples, results or sources.
- No deliberate typos, grammar mistakes or odd thesaurus words. A supervisor still reads the text.
- Borrow sentence skeletons from human writing, not wording. No more than a few generic words in a row from any donor text.
- Measure, don't guess. Report the real score and which detector produced it. Never promise a pass on a detector you did not run.
- If the user can give their own notes or phrasing, start from those. Their own sentences are the best human material.
- Do not create accounts or read results hidden behind a sign-up wall. GPTZero shows results only after login, so ask the user to run that check.

## What the papers say
- Detectors come in three kinds: trained classifiers (RoBERTa style), zero-shot statistics (perplexity, burstiness, log-rank, DetectGPT) and watermarks.
- DIPPER: paraphrase whole paragraphs in context, with high lexical diversity (about 60 percent of words changed) and content reordering. L60/O60 gave the largest drops in detection while meaning stayed intact. Rewrite about three sentences at a time with the already rewritten text as context. Sampling several paraphrases and keeping the one the detector misses is stronger still.
- SICO, step 1 (feature extraction): show the model AI and human texts of the same task, labelled P1 (AI) and P2 (human), and ask: "Compare and give the key distinct feature (specifically vocabulary, sentence structure) of P2's writings (do not show specific examples)." For academic writing the feature it found was: humans give specific details, dates, numbers and names, and use more complex structures with semicolons and parenthetical phrases, while staying clear and concise.
- SICO, step 2 (substitution optimisation): improve the text with greedy substitutions. At word level, use WordNet synonyms for content words with the same part of speech, checked for fit. At sentence level, use paraphrases written with the feature text. Keep a change only if the proxy detector's AI probability drops. The optimised examples matter far more than the feature text, and plain human examples on their own do not help.
- The popular "add perplexity and burstiness" prompt is weak (SICO's Human Prompt baseline).

## What we observed on ZeroGPT (November 2026)
- Every whole-text restyle of an LLM draft scored 100 percent: synonym swaps, casual first person, dense passive voice, short plain sentences, reordering and mixed registers.
- ZeroGPT is deterministic and judges sentences in context. Strongly human sentences pull their neighbours (mostly the next two) toward human, and one AI-sounding sentence can flip the sentences around it. Adding the single word "concrete" flipped two sentences.
- "e.g.", "i.e." and "et al." split sentences into fragments that are judged separately. Avoid e.g. and i.e.; keep et al. in citations.
- Genuine pre-2022 human abstracts score 0 percent even after current jargon (CSRD, ESRS E1, Scope 3, SBTi, CapEx) is swapped in. The topic is not the problem; the phrasing is.
- Probe artefact: pasting paraphrased duplicates into a text lowers the score. Never judge a sentence by inserting it next to its own duplicate, and never ship duplicated content.
- What worked:
  1. Skeleton transfer from real human abstracts of the same genre.
  2. Secondary content moved into parenthetical asides. Putting the research gap inside "(and not only the completeness, which most studies of the first ESRS reports have checked)" took a draft from 34 percent to 0 percent.
  3. Paired parenthetical lists such as "transparency (Scope 3 boundaries, supplier engagement) and ambition (validation by the Science Based Targets initiative)".
  4. A plain, understated closing sentence with a parenthesis instead of a separate implications sentence.
- Local proxies did not track ZeroGPT: GPT-2 perplexity and burstiness, Fast-DetectGPT with GPT-2, and a TF-IDF classifier trained on M4 arXiv (human vs ChatGPT abstracts). Use the live detector.

## Procedure
1. Lock content. Number every claim (an abstract usually has 10 to 15). This list is the acceptance test.
2. Calibrate. Score the user's text and one or two genuine human texts of the same genre (pre-2022 abstracts from IDEAS/RePEc or a journal page). The human texts should score about 0 percent. If they do not, tell the user the detector cannot separate this genre.
3. Extract features (SICO step 1). Compare three to five human and AI texts of the genre with the SICO prompt and note the human features and the AI tells.
4. Draft by skeleton transfer:
   - Open with a strong human-style aim sentence, reordering content if needed (DIPPER order diversity).
   - Give each content point a generic human construction from the phrase bank and fill it with the user's content in fresh words.
   - Move secondary content (research gap, caveats, implications) into parenthetical asides.
   - Stay at the user's length or shorter. Every extra sentence is a new risk.
5. Test with the harness below. Record the score and the flagged sentences.
6. Repair greedily from the best passing version, never from a 100 percent version (the objective is flat there):
   - Change only flagged sentences, one or two at a time, try two variants and keep the lower score.
   - If a sentence keeps failing, fold its content into a strong neighbour as a parenthesis, or move it.
   - Add missing content one item at a time and re-test after each addition.
7. Audit. Check every locked claim with a script, read the text aloud for flow and tense, and re-test the final text both alone and with a heading line above it.
8. Report the text, the measured score for each detector, what was not tested (usually GPTZero), and any meaning compromise such as a dropped adjective. Warn that small edits can flip the score, so the user should re-check after editing.

## Phrase bank (generic constructions that passed)
- "This project aims to examine the [property] of [disclosures/data] dealing with [topic] among [population] with a relatively [large/small] [attribute]."
- "Under [regulation] [actors] have to [obligation] using [standard]."
- "It also considers whether [question], now that [change]."
- "A coding checklist will be constructed based on [source A] and [source B] to identify and categorise [items]."
- "[Concept] is gauged according to [criterion], derived from the link between [a], [b] and [c], with [d] (...) and [e] (...) as further indicators."
- "A content analysis is used to gauge the [property] (and not only the [other property], which most studies of [prior work] have checked) of the [items] of [N] companies listed on [index], in [sectors]."
- "[Tool] is used to extract [variables], and [promises] are compared with [plans]."
- "Knowing which [cases] hold together and which do not should be of some practical use for [stakeholders] (all of whom have to [task])."

## AI tells to remove (all were flagged)
- Paired where-clauses: "where X hold together and where they fall short"
- Stakeholder payoffs: "giving A, B and C a practical way to ..."
- Gap formulas as standalone sentences: "Most studies ... have checked ...", "Far fewer have asked whether ...", "far fewer whether ..."
- "Consequently, ...", "X changed one important thing: ...", colon reveals
- "Credibility is understood as ...", "concrete levers", "serves as a measure of", "so that ... can be set against ...", "The results are expected to show ..."
- Tidy triads in the closing sentence; e.g. and i.e.

## ZeroGPT harness (Claude in Chrome)
Load the chrome-browser skill, open https://www.zerogpt.com/ in a new tab, then define the helpers once with javascript_tool:

```js
if (!window._hooked) {
  const of = window.fetch;
  window.fetch = async (...a) => { const r = await of(...a); try { const u = (a[0] && a[0].url) || String(a[0]); if (/detect/i.test(u)) r.clone().text().then(t => { window._lastDetect = t; }); } catch (e) {} return r; };
  window._hooked = true;
}
window.zscore = async (text) => {
  window._lastDetect = null;
  const ta = document.querySelector('textarea');
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(ta, text);
  ta.dispatchEvent(new Event('input', {bubbles: true}));
  [...document.querySelectorAll('button')].find(b => b.innerText.trim() === 'Detect Text').click();
  for (let k = 0; k < 40 && !window._lastDetect; k++) await new Promise(r => setTimeout(r, 500));
  const d = JSON.parse(window._lastDetect).data;
  return {fake: d.fakePercentage, words: d.textWords, flagged: (d.h || []).map(s => s.slice(0, 60))};
};
'ready'
```

Run at most two `await window.zscore(text)` calls per javascript_tool call, because calls time out after about 45 seconds. `fake` is the share of words ZeroGPT marks as AI and `flagged` lists the flagged sentences. Close the tab when done.

GPTZero (gptzero.me) needs a login to show results, so the user runs that check.