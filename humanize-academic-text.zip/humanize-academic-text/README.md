# humanize-academic-text

A Claude skill that rewrites academic text you wrote (abstracts, proposals, essay paragraphs) so it reads like natural human writing and scores low on AI detectors such as ZeroGPT and GPTZero, without changing what the text says.

It turns two research papers into a repeatable procedure and adds what worked in practice when testing against ZeroGPT.

## How it works

1. **Lock the content.** Every claim, number, citation and method in your text is listed first and checked again at the end.
2. **Calibrate the detector.** Genuine human texts of the same genre should score about 0%. If they don't, the detector can't tell the two apart for that genre.
3. **Extract features (SICO).** Compare human and AI texts of the genre to find what separates them.
4. **Skeleton transfer.** Rewrite each point using sentence structures taken from real human academic writing. Move side points (the research gap, caveats, implications) into parentheses.
5. **Test and repair.** Score the text on a live detector and fix only the flagged sentences, one or two at a time. Always work from the best passing version.
6. **Audit.** Every original claim is present, the text reads naturally, and the final score is reported honestly.

The skill includes a phrase bank of constructions that passed, a list of typical AI phrasings that got flagged, and a small JavaScript helper that checks text on ZeroGPT through Claude in Chrome.

## Install

**Claude Code:** copy the `humanize-academic-text` folder into `~/.claude/skills/`.

**Claude apps:** zip the folder and upload it as a custom skill in Claude's settings.

Then ask something like: *"This abstract is flagged as AI. Humanize it and keep the content the same."*

## Based on

- Krishna, K., Song, Y., Karpinska, M., Wieting, J., & Iyyer, M. (2023). *Paraphrasing evades detectors of AI-generated text, but retrieval is an effective defense.* NeurIPS 2023. arXiv:2303.13408
- Lu, N., Liu, S., He, R., Wang, Q., Ong, Y.-S., & Tang, K. (2024). *Large Language Models can be Guided to Evade AI-Generated Text Detection.* TMLR. arXiv:2305.10847

## Limitations

- The detector observations come from ZeroGPT in November 2026. Detectors change often, so always re-test.
- GPTZero shows results only after login, so that check has to be run by hand.
- Small edits can flip a score. Re-check the text after every change.
- No guarantee: the skill reports the scores it measured and nothing more.

## Responsible use

Use this skill on your own writing and ideas. Many universities and journals require you to disclose AI assistance, so check your institution's policy.

## License

MIT
